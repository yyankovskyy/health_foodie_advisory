from engine import load_json, recommend, taste_hints_from_receipts


def demo(profile_id='guest',**kw):
    p=next(x for x in load_json('profiles.json') if x['id']==profile_id)
    return recommend(p,load_json('recipes_demo.json'),kw.get('meal_type','Any'),kw.get('budget_usd',100),kw.get('max_minutes',120),kw.get('servings',1),kw.get('selected_cuisines'),kw.get('avoid_ingredients'),kw.get('use_receipt_hints',False),load_json('receipts_curated.json'))


def test_deduplicate_payment_slip():
    r=load_json('receipts_curated.json')
    hints=taste_hints_from_receipts(r)
    assert hints['sampled_food_lines'] > 100
    assert hints['distinct_purchase_events'] == 12
    assert hints['tags'].get('vegan_item')==1


def test_peanut_allergy_blocks_pad_thai():
    p=next(x for x in load_json('profiles.json') if x['id']=='guest')
    p['confirmed_food_allergens']=['peanut']
    result=recommend(p,load_json('recipes_demo.json'),'dinner',100,120)
    assert any(x['recipe']['name']=='Pad Thai' for x in result['excluded'])
    assert all(x['recipe']['name']!='Pad Thai' for x in result['candidates'])


def test_sesame_allergy_blocks_bibimbap():
    p=next(x for x in load_json('profiles.json') if x['id']=='guest')
    p['confirmed_food_allergens']=['sesame']
    result=recommend(p,load_json('recipes_demo.json'),'Any',100,120)
    assert any(x['recipe']['name']=='Bibimbap' for x in result['excluded'])


def test_unknown_allergy_cross_contact_causes_review():
    p=next(x for x in load_json('profiles.json') if x['id']=='guest')
    p['confirmed_food_allergens']=['peanut']
    result=recommend(p,load_json('recipes_demo.json'),'Any',100,120)
    assert all(x['allergy_review_required'] for x in result['candidates'])


def test_budget_and_time_filters():
    r=demo(budget_usd=5,max_minutes=25)
    assert all(x['estimated_total_cost_usd']<=5 and x['recipe']['time_minutes_demo']<=25 for x in r['candidates'])


def test_multi_portion_budget():
    r=demo(budget_usd=7,servings=2,max_minutes=120)
    assert all(x['estimated_total_cost_usd']<=7 for x in r['candidates'])


def test_diabetes_has_nutrition_uncertainty():
    r=demo('daniel',budget_usd=100)
    assert r['candidates']
    assert all(any('DEMO' in c for c in x['cautions']) for x in r['candidates'])


def test_marina_daily_sodium_not_falsely_translated_to_per_meal():
    r=demo('marina',budget_usd=100)
    assert r['candidates']
    assert all(any('Daily sodium' in c for c in x['cautions']) for x in r['candidates'])


def test_egg_not_false_match_eggplant():
    result=demo(avoid_ingredients=['egg'],budget_usd=100)
    assert any(x['recipe']['name']=='Ratatouille' for x in result['candidates'])
    assert any(x['recipe']['name']=='Menemen' for x in result['excluded'])


def test_new_receipt_photos_present():
    r=load_json("receipts_curated.json")
    files={x["source_file"] for x in r}
    assert all(f"IMG_{i}.jpeg" in files for i in range(2563,2573))


def test_curated_compatibility_files_match():
    assert load_json("receipts_curated.json")==load_json("receipt_curated.json")==load_json("receipts_demo.json")


def test_reconcile_complete_photo_amounts():
    receipts=load_json("receipts_curated.json")
    for id in ["grocery_outlet_2564", "whole_foods_los_altos_2566", "grocery_outlet_2567", "safeway_2569", "grocery_outlet_2570", "trader_joes_2571", "grocery_outlet_2572"]:
        r=next(x for x in receipts if x["receipt_id"]==id)
        assert abs(r["food_purchase_subtotal_identified"]-r["receipt_total"]) < .01, id


def test_missing_totals_not_invented():
    receipts=load_json("receipts_curated.json")
    assert next(x for x in receipts if x["receipt_id"]=="trader_joes_2565")["receipt_total"] is None
    assert next(x for x in receipts if x["receipt_id"]=="grocery_outlet_2568")["receipt_total"] is None
