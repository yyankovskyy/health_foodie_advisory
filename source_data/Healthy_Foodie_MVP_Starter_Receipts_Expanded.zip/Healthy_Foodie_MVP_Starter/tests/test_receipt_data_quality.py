"""Integrity checks for manually transcribed receipt fixtures."""
import hashlib
from pathlib import Path

from engine import load_json, taste_hints_from_receipts


def test_input_record_ids_and_image_coverage():
    data = load_json('receipts_demo.json')
    ids = [r['receipt_id'] for r in data]
    assert len(ids) == len(set(ids)) == 13
    assert {r['source_file'] for r in data} == {
        'IMG_2557.jpeg', 'IMG_2558.jpeg', 'IMG_2559.jpeg',
        *(f'IMG_{i}.jpeg' for i in range(2563, 2573)),
    }
    assert len([r for r in data if not r.get('duplicate_of')]) == 12


def test_visible_food_subtotals_arithmetic():
    for r in load_json('receipts_demo.json'):
        assert r['currency'] in ('USD', 'EUR')
        assert abs(sum(item['price'] or 0 for item in r['foods']) -
                   r['food_purchase_subtotal_identified']) < 0.011, r['source_file']
        assert all(item.get('confidence') in ('low', 'medium', 'high')
                   for item in r['foods'])
        assert all(item['price'] is None or item['price'] >= 0
                   for item in r['foods'])
        if r.get('duplicate_of'):
            assert not r['foods']


def test_unknown_receipt_amounts_remain_unknown():
    data = {r['source_file']: r for r in load_json('receipts_demo.json')}
    assert data['IMG_2565.jpeg']['receipt_total'] is None
    assert data['IMG_2568.jpeg']['receipt_total'] is None
    assert sum(i['price'] is None for i in data['IMG_2565.jpeg']['foods']) >= 9


def test_receipt_compatibility_aliases_and_purchase_count():
    assert load_json('receipt_curated.json') == load_json('receipts_demo.json') == load_json('receipts_curated.json')
    data = load_json('receipts_demo.json')
    assert sum(len(r['foods']) for r in data) == 131
    hints = taste_hints_from_receipts(data)
    assert hints['distinct_purchase_events'] == 12
    assert hints['sampled_food_lines'] == 131
