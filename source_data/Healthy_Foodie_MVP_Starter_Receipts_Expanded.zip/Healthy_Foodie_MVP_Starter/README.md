# Healthy Foodie - Minimal Hackathon Starter

This is an **optional runnable starter** corresponding to the lean implementation blueprint. It has only Streamlit + Python; no agent platform, database, or API key is needed for the first demonstration.

## Run locally (macOS/Linux)

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
streamlit run app.py
```

## Verify core behavior

```bash
python -m pytest -q
```

## Included sources / limitations

- `data/profiles.json`: manually normalized minimal facts from **two attached fictional patient PDF summaries**, not live extraction.
- `data/recipes_demo.json`: 10 recipe *titles, cuisine tags, partial ingredient summaries, and original publisher links* from the user-provided World Cuisines guide. **Every numeric price and nutrient field is invented for UI/testing** and should NOT be represented as measured or source-verified. Ingredient lists are NOT complete. Follow publisher link and license before production ingestion.
- `data/receipts_curated.json`: hand-reviewed, de-identified items from the original three photographs and **ten new receipt photographs**, representing **twelve distinct purchase events**. The Frankfurt payment slip is a duplicate and is not counted as another purchase. Missing receipt dates/prices remain `null`; ambiguous product interpretations carry confidence flags. Only historical package prices are included; no payment card numbers, SNAP balances or identifiable transaction IDs are stored.
- `data/receipt_curated.json` and `data/receipts_demo.json`: compatibility copies of the same curated receipt records. The app continues loading `receipts_curated.json` as its canonical fixture.
- No claims of clinical suitability or allergen safety. For real users, verified full ingredients, cross-contact information, accurate food composition, clinical review, privacy controls and patient consent are prerequisites.

## Milestone map

1. **R1** - UI, local records, simple meal filtering: present now.
2. **R2** - Confirmed allergen blocking, clinician note display, uncertainty: present now at illustrative demo level.
3. **R3** - User budget and time filters, recipe attribution, receipt taste hints: present now; costs demo only.
4. **R4** - Optional LLM explanation: add after offline demo succeeds. Pass only de-identified, non-sensitive details; do not let model determine allergen safety or clinical values.
5. **R5** - Uploads and evidence extraction: next iteration, not a prerequisite to run.

## Deliberate non-features

No live receipt OCR, no production medical document ingestion, no real patient profiles, no automatic daily calorie prescription, no nutrient validation, no price lookups, no account authentication, no payments, no S3 deployment, no live model call. These must be added with verification and privacy controls. One use of 'vegan' in a receipt cannot define a permanent dietary identity.

## Reference data sources

- Nutrition: user-provided *Evidence-Based Nutrition Guidance* (US/EU/UK, 19 Nov 2026); authoritative medical citations remain in that document.
- Recipes: user-provided *World Cuisines & Recipes* (18 Nov 2026), recipes 1-45, plus links.
- Medical fixtures: attached synthetic Marina Ellis and Daniel Ortiz PDF records.
- Receipts: original Whole Foods and Frankfurt photographs plus new Whole Foods, Grocery Outlet, Trader Joe's and Safeway images (IMG_2563.jpeg through IMG_2572.jpeg).
- Later nutrition matching: [USDA FoodData Central API Guide](https://fdc.nal.usda.gov/api-guide/) (API key required).
- UI: [Streamlit upload reference](https://docs.streamlit.io/develop/api-reference/widgets/st.file_uploader).

## Receipt capture rules

- Each distinct photograph is a transaction fixture unless documented as a duplicate payment slip. Same-product purchase lines within one receipt are retained separately.
- `price` is the printed extended line price (USD/EUR), not a per-serving recipe cost. Optional `quantity`, `quantity_unit`, and `unit_price` retain the source measure.
- `food_purchase_subtotal_identified` totals only price-confirmed food entries; it can be below `receipt_total` when images are cut off, a line is illegible, or deposits/non-food charges occur.
- Unknown `receipt_total`, date, item prices and identities are `null` or marked low-confidence. Dates are not inferred from upload date.
- No nutrition facts, allergies or product-level cross-contact certifications are inferred from a purchase.
