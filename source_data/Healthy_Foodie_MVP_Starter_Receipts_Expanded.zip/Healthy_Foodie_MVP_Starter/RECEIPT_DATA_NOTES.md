# Receipt data expansion: image sources and QA

This data package contains hand-verified transcription examples from 13 receipt images, representing 12 distinct purchases. The Frankfurt card slip is evidence of the food receipt payment and is marked with `duplicate_of`; the app excludes that slip from purchase counts.

## Dataset inventory

- Initial images: `IMG_2557.jpeg`, `IMG_2558.jpeg`, `IMG_2559.jpeg` (3 records; 2 purchases).
- Added images: `IMG_2563.jpeg` through `IMG_2572.jpeg` (10 records; 10 purchases).
- Food line entries: 131, including repeat purchased products shown as distinct line items.
- Three identical JSON entry points: `data/receipts_curated.json` (app's canonical file), `data/receipt_curated.json` (requested alias), and `data/receipts_demo.json` (requested alias).

## Integrity / interpretation guidance

- `price` means a historic printed extended line amount in the receipt's native `currency`, not price per serving or an up-to-date quote. Where shown, `quantity`, `quantity_unit`, and `unit_price` can have different bases (items vs lb).
- Missing receipt dates, totals, quantities, and individual prices remain `null`; no guesses or synthetic prices have been added to receipt fixtures.
- Only unambiguously food-related lines are counted as food purchases. Deposits, nonfood purchases, tender/payment metadata, and illegible entries are excluded or explicitly noted.
- `interpretation`, `category`, and `tags` are *manual interpretations* of abbreviated descriptions, not verified ingredients, allergies, nutrition labels, or actual user preferences. Low-confidence products must not be used for clinical screening.
- The Trader Joe's image IMG_2565.jpeg is folded, partly occluded and cropped; its `receipt_total` is unknown, and its `food_purchase_subtotal_identified` covers the visible priced items only.
- No payment-card digits, benefits balances, trace identifiers, or other account identifiers are stored in the JSON. Source receipt photos themselves are NOT bundled in the ZIP.

## Validating

```bash
python -m pytest -q
```

The tests verify the 13 source IDs, 12 distinct purchase count, JSON compatibility, subtotal arithmetic, proper nulls for missing values, and 131 food lines.
