import streamlit as st
from engine import load_json, recommend

st.set_page_config(page_title="Healthy Foodie - staged MVP", layout="wide")
st.title("Healthy Foodie | Meal discovery MVP")
st.caption("Synthetic clinical profiles. Demo nutrition and costs are unverified estimates. This app does NOT certify allergy or medical safety.")
profiles=load_json("profiles.json")
recipes=load_json("recipes_demo.json")
receipts=load_json("receipts_curated.json")

with st.sidebar:
    st.header("Your meal preferences")
    profile_id=st.selectbox("Synthetic profile",[p["id"] for p in profiles],format_func=lambda i:next(p["display_name"] for p in profiles if p["id"]==i))
    profile=next(p for p in profiles if p["id"]==profile_id)
    meal=st.selectbox("Meal",["Any","breakfast","lunch","dinner"])
    budget=st.number_input("Total food budget (USD; DEMO estimates)",min_value=2.0,max_value=200.0,value=12.0,step=1.0)
    maximum=st.slider("Maximum cooking time (minutes)",10,120,45,5)
    servings=st.number_input("Portions",min_value=1,max_value=8,value=1)
    cuisines=st.multiselect("Cuisine (optional)",sorted({r["cuisine"] for r in recipes}))
    allergies=st.multiselect("Test with confirmed food allergy (synthetic)",["peanut","sesame","milk","egg","fish","wheat","soy","shellfish","tree_nuts"])
    avoid=st.text_input("Avoid ingredient(s), separated by commas",placeholder="e.g. tomato, garlic")
    use_purchases=st.checkbox("Use sample purchases as weak taste hints",value=False)

effective_profile=dict(profile)
effective_profile["confirmed_food_allergens"]=sorted(set(profile["confirmed_food_allergens"])|set(allergies))
result=recommend(effective_profile,recipes,meal,budget,maximum,servings,cuisines,[x.strip() for x in avoid.split(',')],use_purchases,receipts)

st.subheader("Profile summary")
st.write("**Selected profile:**",profile['display_name'])
if profile["diagnoses"]:
    st.write("**Simulation-only medical conditions:**", "; ".join(profile["diagnoses"]))
if profile["prescribed_constraints"]:
    st.info("Synthetic clinician constraints: " + "; ".join(f"{c['metric']} {c.get('max',c.get('target_approx','?'))} ({c['scope']})" for c in profile['prescribed_constraints'])+". All recipe nutrient values below are unverified demo estimates.")

if use_purchases:
    st.write("**Receipt-derived weak hints:**",result['taste_hints']['tags'])
    st.caption("Payment details, deposits and nonfood lines excluded; Frankfurt card slip deduplicated. Missing receipt data stays unknown. Purchases are weak signals, not medical or allergy evidence.")

st.subheader(f"Preliminary options ({len(result['candidates'])})")
if not result['candidates']:
    st.warning("No demo options under current filters. Try another meal, budget, or time; do not relax confirmed allergy exclusions.")
for item in result['candidates'][:6]:
    r=item['recipe']
    with st.expander(f"{r['name']} · {r['cuisine']} · {r['time_minutes_demo']} min · ${item['estimated_total_cost_usd']:.2f} DEMO",expanded=True):
        st.write("**Illustrative nutrition / serving:**",f"~{r['energy_kcal_per_serving_demo']} kcal, ~{r['carbohydrate_g_per_serving_demo']} g carbohydrate, ~{r['sodium_mg_per_serving_demo']} mg sodium")
        st.write("**Ingredient overview (not complete):**",r['ingredient_summary'])
        st.markdown(f"[Open original complete recipe]({r['source_url']})")
        for caution in item['cautions']:
            st.warning(caution)
        if item['allergy_review_required']:
            st.error("NOT VERIFIED FOR FOOD ALLERGY. Do not interpret as safe to eat.")

if result['excluded']:
    with st.expander(f"Excluded for identified restricted ingredients ({len(result['excluded'])})"):
        for x in result['excluded']:
            st.write(x['recipe']['name'] + ': ' + x['reason'])

st.divider()
st.caption("No uploaded real health records, payment identifiers, or receipt photos are stored in the MVP. Seek a clinician or registered dietitian for patient-specific dietary decisions.")
